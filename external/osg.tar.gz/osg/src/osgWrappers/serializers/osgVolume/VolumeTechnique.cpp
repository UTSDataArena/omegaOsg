#include <osgVolume/VolumeTechnique>
#include <osgDB/ObjectWrapper>
#include <osgDB/InputStream>
#include <osgDB/OutputStream>

REGISTER_OBJECT_WRAPPER( osgVolume_VolumeTechnique,
                         new osgVolume::VolumeTechnique,
                         osgVolume::VolumeTechnique,
                         "osg::Object osgVolume::VolumeTechniquee" )
{
}
