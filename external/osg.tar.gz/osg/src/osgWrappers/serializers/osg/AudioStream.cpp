#include <osg/AudioStream>
#include <osgDB/ObjectWrapper>
#include <osgDB/InputStream>
#include <osgDB/OutputStream>

REGISTER_OBJECT_WRAPPER( AudioStream,
                         /*new osg::AudioStream*/NULL,
                         osg::AudioStream,
                         "osg::Object osg::AudioStream" )
{
}
