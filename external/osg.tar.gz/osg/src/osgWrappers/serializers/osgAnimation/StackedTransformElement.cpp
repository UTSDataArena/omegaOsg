#include <osgAnimation/StackedTransformElement>
#include <osgDB/ObjectWrapper>
#include <osgDB/InputStream>
#include <osgDB/OutputStream>

REGISTER_OBJECT_WRAPPER( osgAnimation_StackedTransformElement,
                         /*new osgAnimation::StackedTransformElement*/NULL,
                         osgAnimation::StackedTransformElement,
                         "osg::Object osgAnimation::StackedTransformElement" )
{
}
