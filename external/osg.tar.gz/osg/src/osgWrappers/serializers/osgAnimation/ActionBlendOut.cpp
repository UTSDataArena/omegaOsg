#include <osgAnimation/ActionBlendOut>
#include <osgDB/ObjectWrapper>
#include <osgDB/InputStream>
#include <osgDB/OutputStream>

REGISTER_OBJECT_WRAPPER( osgAnimation_ActionBlendOut,
                         new osgAnimation::ActionBlendOut,
                         osgAnimation::ActionBlendOut,
                         "osg::Object osgAnimation::Action osgAnimation::ActionBlendOut" )
{
}
